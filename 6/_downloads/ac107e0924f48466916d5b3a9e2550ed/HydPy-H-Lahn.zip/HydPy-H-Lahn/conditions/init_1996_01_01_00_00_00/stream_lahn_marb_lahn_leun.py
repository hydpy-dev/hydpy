from hydpy.models.musk_classic import *

controlcheck(projectdir=r"HydPy-H-Lahn", controldir="default")

discharge(10.0, 10.0)
