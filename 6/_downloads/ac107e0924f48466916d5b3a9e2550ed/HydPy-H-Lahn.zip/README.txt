This README describes a Hydpy 6.2.0 example project.
© 2013-2025 HydPy Developers
https://github.com/hydpy-dev/hydpy/

`HydPy-H-Lahn` is a complete project data set for the German river Lahn, provided by the
German Federal Institute of Hydrology (BfG) [https://www.bafg.de/EN].  The Lahn is a
medium-sized tributary to the Rhine. The catchment consists of four sub-catchments, each
with a river gauge (Marburg, Asslar, Leun, Kalkofen) at its outlet.  The sub-catchments
consist of a different number of zones.

The meteorological input data stems from the gridded precipitation data set HYRAS-DE PRE
v5.0, the gridded temperature dataset HYRAS-DE TAS v5.0, and the gridded global shortwave
radiation dataset HYRAS-DE RSDS v3.0 of the German Weather Service (DWD), which was
spatially averaged over HydPy-H-HBV96 subbasins by the German Federal Insitute of
Hydrology.  The Hessian Agency for Nature Conservation, Environment and Geology (HLNUG)
kindly provides the measurement data for the gauges Marburg and Asslar, and the Federal
Waterways and Shipping Administration (WSV) those of Kalkofen and Leun. All this time
series data is licensed under Attribution-NonCommercial-ShareAlike International 4.0 (CC
BY-NC-SA 4.0) [https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.en].

